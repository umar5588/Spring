package com.spring;

public class Event {
	String eventName;
	String eventOrganiser;
	Double fare;
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventOrganiser() {
		return eventOrganiser;
	}
	public void setEventOrganiser(String eventOrganiser) {
		this.eventOrganiser = eventOrganiser;
	}
	public Double getFare() {
		return fare;
	}
	public void setFare(Double fare) {
		this.fare = fare;
	}
	public void display() {
		//Fill your code here
		System.out.println("eventName="+eventName);
		System.out.println("eventOrganiser="+eventOrganiser);
		System.out.println("fare="+fare);
	}
}
